<h1>Registration Successful</h1>
<p>Your registration is pending admin approval. You will be notified once your account is activated.</p>
