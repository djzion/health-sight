<!DOCTYPE html>
<html>
<head>
    <title>Registration Pending</title>
</head>
<body>
    <h2>Registration Pending Approval</h2>
    <p>Hello {{ $userData['userName'] }},</p>
    <p>Thank you for registering with HealthSight. Your account is currently pending administrator approval.</p>
    <p>We'll notify you once your account has been reviewed and approved.</p>
    <p>Thank you,<br>HealthSight Team</p>
</body>
</html>
