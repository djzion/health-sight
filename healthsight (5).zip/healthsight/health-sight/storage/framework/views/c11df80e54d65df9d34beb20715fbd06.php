<table class="table">
    <thead>
        <tr>
            <th>Database ID</th>
            <th>Order Field</th>
            <th>Creation Order</th>
            <th>Question</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($assessment->id); ?></td>
            <td><?php echo e($assessment->order ?? 'N/A'); ?></td>
            <td><?php echo e($assessment->created_at); ?></td>
            <td><?php echo e($assessment->question); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\healthsight\resources\views/debug-assessments.blade.php ENDPATH**/ ?>