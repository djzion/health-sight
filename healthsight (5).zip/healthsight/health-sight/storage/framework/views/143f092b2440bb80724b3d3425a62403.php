<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Total Users Card -->
    <div class="row">
        <!-- Total Users Card -->
        <div class="col-lg-3 col-md-6">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Users</h5>
                    <p class="card-text"><?php echo e($totalUsers ?? 0); ?></p>
                </div>
            </div>
        </div>

    <!-- Total PHCs Card -->
    <div class="col-lg-3 col-md-6">
        <div class="card text-white bg-success mb-3">
            <div class="card-body">
                <h5 class="card-title">Total PHCs</h5>
                <p class="card-text"><?php echo e($totalPHCs); ?></p>
            </div>
        </div>
    </div>

    <!-- Pending Applications Card -->
    <div class="col-lg-3 col-md-6">
        <div class="card text-white bg-warning mb-3">
            <div class="card-body">
                <h5 class="card-title">Pending Registrations</h5>
                <p class="card-text"><?php echo e($pendingApplications); ?></p>
            </div>
        </div>
    </div>

    <!-- Rejected Applications Card -->
    <div class="col-lg-3 col-md-6">
        <div class="card text-white bg-danger mb-3">
            <div class="card-body">
                <h5 class="card-title">Rejected Registrations</h5>
                <p class="card-text"><?php echo e($rejectedApplications); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <!-- Recent Users List -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Recent Users</div>
            <div class="card-body">
                <?php if($recentUsers->isEmpty()): ?>
                    <p>No recent users available.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0"><?php echo e($user->full_name); ?></h6>
                                    <small class="text-muted"><?php echo e($user->role->name); ?></small>
                                </div>
                                <span class="badge bg-primary rounded-pill">New</span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent PHCs List -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Recent PHCs</div>
            <div class="card-body">
                <?php if($recentPHCs->isEmpty()): ?>
                    <p>No recent PHCs available.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php $__currentLoopData = $recentPHCs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0"><?php echo e($phc->name); ?></h6>
                                    <small class="text-muted"><?php echo e($phc->location); ?></small>
                                </div>
                                <small class="text-muted"><?php echo e($phc->created_at->diffForHumans()); ?></small>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\healthsight\resources\views/layouts/app.blade.php ENDPATH**/ ?>